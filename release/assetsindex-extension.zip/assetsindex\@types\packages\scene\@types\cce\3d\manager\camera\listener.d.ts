import { Camera } from '.';
/**
 * 将摄像机操作绑定到摄像机管理器上
 * @param {*} camera
 */
declare function bind(camera: Camera): void;
export default bind;
//# sourceMappingURL=listener.d.ts.map