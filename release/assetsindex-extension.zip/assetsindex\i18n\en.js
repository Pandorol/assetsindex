"use strict";module.exports={open_panel:"opendymenu",
    send_to_panel:"Send message to Default Panel",
    description:"Extension with a panel",
    resourcesdeal:"Resources Deal",};