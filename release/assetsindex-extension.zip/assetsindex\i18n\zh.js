"use strict";module.exports={
    open_panel:"打开面板工具",
    send_to_panel:"发送消息给面板",
    description:"含有一个面板的扩展",
    gen_index:"构建索引表",
    resourcesdeal:"资源处理",
};