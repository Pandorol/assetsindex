import IconGizmoBase from './icon-gizmo-base';
declare class ParticleSystemIconGizmo extends IconGizmoBase {
    createController(): void;
}
export default ParticleSystemIconGizmo;
//# sourceMappingURL=particle-system-icon-gizmo.d.ts.map