declare function check(): void;
export { check };
//# sourceMappingURL=preload.d.ts.map