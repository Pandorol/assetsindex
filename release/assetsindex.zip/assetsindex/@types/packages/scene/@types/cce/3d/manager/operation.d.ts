import operation from '../../public/operation';
export default operation;
//# sourceMappingURL=operation.d.ts.map