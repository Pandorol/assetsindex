import SceneManager from './scene-manager';
declare const sceneManager: SceneManager;
export default sceneManager;
//# sourceMappingURL=index.d.ts.map