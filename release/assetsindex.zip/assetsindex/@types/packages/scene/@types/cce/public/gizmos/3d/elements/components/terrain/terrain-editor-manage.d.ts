/**
 * @category terrain
 */
import { TerrainEditorMode } from './terrain-editor-mode';
export declare class TerrainEditorManage extends TerrainEditorMode {
}
//# sourceMappingURL=terrain-editor-manage.d.ts.map